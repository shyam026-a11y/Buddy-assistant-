package com.shyam026.buddyassistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final String PREFS="buddy_prefs", API_KEY="openrouter_key";
    private SharedPreferences prefs;
    private TextView status, transcript, reply;
    private Button listen;
    private CheckBox handsFree;
    private SpeechRecognizer speech;
    private TextToSpeech tts;
    private boolean ttsReady=false;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        tts=new TextToSpeech(this,r->{
            if(r==TextToSpeech.SUCCESS){
                ttsReady=true;
                tts.setSpeechRate(1f);
                tts.setPitch(1.08f);
                tts.setLanguage(new Locale("hi","IN"));
            }
        });
        if(prefs.getString(API_KEY,"").trim().isEmpty()) setup(); else main();
    }

    private TextView tv(String s,int sp){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp);
        t.setPadding(24,18,24,18); return t;
    }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }

    private void setup(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(30,50,30,30);
        TextView title=tv("Buddy Assistant",28); title.setGravity(Gravity.CENTER);
        box.addView(title);
        TextView info=tv("First launch: apni OpenRouter API key paste karo. Key isi phone par locally save hogi.",16);
        box.addView(info);
        EditText key=new EditText(this); key.setHint("sk-or-v1-...");
        key.setSingleLine(true); key.setInputType(0x81); box.addView(key);
        Button save=btn("Save & Start");
        save.setOnClickListener(v->{
            String k=key.getText().toString().trim();
            if(k.isEmpty()){ toast("API key enter karo."); return; }
            prefs.edit().putString(API_KEY,k).apply(); main();
        });
        box.addView(save); setContentView(box);
    }

    private void main(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20,25,20,20);

        TextView title=tv("Buddy Assistant",28); title.setGravity(Gravity.CENTER);
        root.addView(title);
        status=tv("Ready",14); root.addView(status);
        transcript=tv("You: —",17); root.addView(transcript);
        reply=tv("Buddy: Ready hoon. Bolo.",18); root.addView(reply);

        listen=btn("🎙 Listen");
        listen.setOnClickListener(v->listenNow());
        root.addView(listen);

        handsFree=new CheckBox(this);
        handsFree.setText("Hands-free: reply ke baad dobara suno");
        root.addView(handsFree);

        Button settings=btn("API Key Settings");
        settings.setOnClickListener(v->apiDialog()); root.addView(settings);

        Button bright=btn("Allow brightness control");
        bright.setOnClickListener(v->allowWriteSettings()); root.addView(bright);

        root.addView(tv("Try: “YouTube kholo”, “volume badhao”, “brightness 50”, “Google pe search JEE cutoff”.",14));
        setContentView(root); initSpeech();
    }

    private void apiDialog(){
        EditText input=new EditText(this); input.setSingleLine(true); input.setInputType(0x81);
        input.setText(prefs.getString(API_KEY,""));
        new AlertDialog.Builder(this).setTitle("OpenRouter API Key").setView(input)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                String k=input.getText().toString().trim();
                if(!k.isEmpty()) prefs.edit().putString(API_KEY,k).apply();
            }).show();
    }

    private void initSpeech(){
        if(!SpeechRecognizer.isRecognitionAvailable(this)){ setStatus("Speech recognition unavailable."); return; }
        speech=SpeechRecognizer.createSpeechRecognizer(this);
        speech.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){ setStatus("Listening…"); listen.setText("🟢 Listening…"); }
            public void onBeginningOfSpeech(){}
            public void onRmsChanged(float r){}
            public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){}
            public void onError(int e){
                listen.setText("🎙 Listen"); setStatus("Speech error");
                if(handsFree!=null && handsFree.isChecked()) listen.postDelayed(MainActivity.this::listenNow,800);
            }
            public void onResults(Bundle r){
                listen.setText("🎙 Listen");
                ArrayList<String> a=r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(a!=null && !a.isEmpty()) handle(a.get(0));
            }
            public void onPartialResults(Bundle p){}
            public void onEvent(int e,Bundle p){}
        });
    }

    private void listenNow(){
        if(speech==null){ initSpeech(); if(speech==null)return; }
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10); return;
        }
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN");
        speech.startListening(i);
    }

    private void handle(String raw){
        transcript.setText("You: "+raw); setStatus("Processing…");
        String s=raw.toLowerCase(Locale.ROOT).trim();

        if(s.contains("youtube") && (s.contains("khol")||s.contains("open")||s.contains("chala"))){
            local("YouTube khol raha hoon.",()->openApp("youtube")); return;
        }
        if(s.contains("chrome") && (s.contains("khol")||s.contains("open"))){
            local("Chrome khol raha hoon.",()->openApp("chrome")); return;
        }
        if(s.contains("whatsapp") && (s.contains("khol")||s.contains("open"))){
            local("WhatsApp khol raha hoon.",()->openApp("whatsapp")); return;
        }
        if(s.contains("settings") && (s.contains("khol")||s.contains("open"))){
            local("Settings khol raha hoon.",()->startActivity(new Intent(Settings.ACTION_SETTINGS))); return;
        }
        if(s.contains("volume")||s.contains("awaz")){
            if(s.contains("badha")||s.contains("up")||s.contains("increase")) local("Volume badha diya.",this::volumeUp);
            else if(s.contains("kam")||s.contains("down")||s.contains("decrease")) local("Volume kam kar diya.",this::volumeDown);
            else if(s.contains("mute")||s.contains("band")) local("Mute kar diya.",this::volumeMute);
            else askAI(raw);
            return;
        }
        if(s.contains("brightness")||s.contains("roshni")||s.contains("screen bright")){
            Integer n=number(s);
            if(n!=null) local("Brightness "+n+" percent kar raha hoon.",()->setBrightness(n));
            else if(s.contains("badha")||s.contains("increase")) local("Brightness badha raha hoon.",()->changeBrightness(25));
            else if(s.contains("kam")||s.contains("decrease")) local("Brightness kam kar raha hoon.",()->changeBrightness(-25));
            else askAI(raw);
            return;
        }
        if(s.startsWith("search ")||s.startsWith("google pe search ")||s.startsWith("google par search ")){
            String q=s.replaceFirst("^google pe search\\s+","")
                      .replaceFirst("^google par search\\s+","")
                      .replaceFirst("^search\\s+","").trim();
            local("Search kar raha hoon.",()->web(q)); return;
        }
        askAI(raw);
    }

    private void askAI(String cmd){
        String key=prefs.getString(API_KEY,"").trim();
        if(key.isEmpty()){ show("API key missing hai."); return; }
        executor.execute(()->{
            try{
                JSONObject body=new JSONObject();
                body.put("model","openrouter/free");
                JSONArray msgs=new JSONArray();
                msgs.put(new JSONObject().put("role","system").put("content",
                    "You are Buddy, a Hindi English Hinglish phone assistant. Return ONLY JSON with keys action,target,value,reply. action must be one of open_app,volume,brightness,web_search,conversation,unknown. Never claim execution; the phone executes it."));
                msgs.put(new JSONObject().put("role","user").put("content",cmd));
                body.put("messages",msgs);

                HttpURLConnection c=(HttpURLConnection)new URL("https://openrouter.ai/api/v1/chat/completions").openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000);
                c.setRequestProperty("Authorization","Bearer "+key);
                c.setRequestProperty("Content-Type","application/json"); c.setDoOutput(true);
                try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}
                InputStream in=(c.getResponseCode()>=200&&c.getResponseCode()<300)?c.getInputStream():c.getErrorStream();
                String out=read(in);
                if(c.getResponseCode()<200||c.getResponseCode()>=300){post("AI request failed.");return;}
                String content=new JSONObject(out).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content","");
                postPlan(clean(content));
            }catch(Exception e){post("AI se response nahi mila. Network/API check karo.");}
        });
    }

    private void postPlan(String json){
        try{
            JSONObject p=new JSONObject(json);
            String a=p.optString("action","unknown").toLowerCase(Locale.ROOT);
            String t=p.optString("target","").trim(), v=p.optString("value","").trim(), r=p.optString("reply","Done.");
            runOnUiThread(()->{
                try{
                    if(a.equals("open_app")){openApp(t);show(r);}
                    else if(a.equals("volume")){ if(v.contains("up")||v.contains("increase"))volumeUp(); else if(v.contains("down")||v.contains("decrease"))volumeDown(); else volumeMute(); show(r);}
                    else if(a.equals("brightness")){ if(isInt(v))setBrightness(Integer.parseInt(v)); else if(v.contains("up")||v.contains("increase"))changeBrightness(25); else changeBrightness(-25); show(r);}
                    else if(a.equals("web_search")){web(t.isEmpty()?v:t);show(r);}
                    else show(r);
                }catch(Exception e){show("Ye action complete nahi ho paya.");}
            });
        }catch(Exception e){post("AI ka JSON response valid nahi tha.");}
    }

    private String clean(String s){
        s=s.trim();
        if(s.startsWith("```")){int n=s.indexOf('\n'); if(n>=0)s=s.substring(n+1); if(s.endsWith("```"))s=s.substring(0,s.length()-3);}
        int a=s.indexOf('{'), b=s.lastIndexOf('}');
        return a>=0&&b>a?s.substring(a,b+1):s;
    }
    private String read(InputStream in)throws Exception{
        if(in==null)return "";
        BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));
        StringBuilder s=new StringBuilder(); String line; while((line=br.readLine())!=null)s.append(line); return s.toString();
    }

    private void local(String text,Runnable action){try{action.run();show(text);}catch(Exception e){show("Ye action phone ne allow nahi kiya.");}}
    private void show(String s){
        runOnUiThread(()->{
            reply.setText("Buddy: "+s); setStatus("Ready"); speak(s);
            if(handsFree!=null&&handsFree.isChecked())listen.postDelayed(MainActivity.this::listenNow,1000);
        });
    }
    private void post(String s){runOnUiThread(()->show(s));}
    private void speak(String s){
        if(!ttsReady||s==null||s.isEmpty())return;
        Locale l=s.matches(".*[\\u0900-\\u097F].*")?new Locale("hi","IN"):new Locale("en","IN");
        int r=tts.setLanguage(l); if(r==TextToSpeech.LANG_MISSING_DATA||r==TextToSpeech.LANG_NOT_SUPPORTED)tts.setLanguage(Locale.US);
        tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"buddy");
    }
    private void setStatus(String s){runOnUiThread(()->{if(status!=null)status.setText(s);});}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private void volumeUp(){((AudioManager)getSystemService(AUDIO_SERVICE)).adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI);}
    private void volumeDown(){((AudioManager)getSystemService(AUDIO_SERVICE)).adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI);}
    private void volumeMute(){((AudioManager)getSystemService(AUDIO_SERVICE)).adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_MUTE,AudioManager.FLAG_SHOW_UI);}

    private void allowWriteSettings(){
        try{
            Intent i=new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+getPackageName()));
            startActivity(i);
        }catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}
    }
    private void setBrightness(int p){
        if(!Settings.System.canWrite(this)){allowWriteSettings();throw new IllegalStateException();}
        p=Math.max(1,Math.min(100,p)); Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,p*255/100);
    }
    private void changeBrightness(int d){
        if(!Settings.System.canWrite(this)){allowWriteSettings();throw new IllegalStateException();}
        int cur=Settings.System.getInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,128);
        Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,Math.max(1,Math.min(255,cur+(255*d/100))));
    }

    private void web(String q){
        if(q==null||q.isEmpty())return;
        try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+URLEncoder.encode(q,"UTF-8"))));}
        catch(Exception e){show("Search open nahi hua.");}
    }

    private void openApp(String target){
        String w=target.toLowerCase(Locale.ROOT).trim(); PackageManager pm=getPackageManager();
        for(ApplicationInfo a:pm.getInstalledApplications(PackageManager.GET_META_DATA)){
            String label=String.valueOf(pm.getApplicationLabel(a)).toLowerCase(Locale.ROOT);
            if(label.equals(w)||label.contains(w)){
                Intent i=pm.getLaunchIntentForPackage(a.packageName);
                if(i!=null){startActivity(i);return;}
            }
        }
        String pkg=null;
        if(w.contains("youtube"))pkg="com.google.android.youtube";
        else if(w.contains("chrome"))pkg="com.android.chrome";
        else if(w.contains("whatsapp"))pkg="com.whatsapp";
        if(pkg!=null){Intent i=pm.getLaunchIntentForPackage(pkg);if(i!=null){startActivity(i);return;}}
        throw new ActivityNotFoundException();
    }

    private Integer number(String s){
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\b(\\d{1,3})\\b").matcher(s);
        return m.find()?Integer.valueOf(m.group(1)):null;
    }
    private boolean isInt(String s){try{Integer.parseInt(s);return true;}catch(Exception e){return false;}}

    @Override protected void onDestroy(){
        super.onDestroy();
        if(speech!=null)speech.destroy();
        if(tts!=null)tts.shutdown();
        executor.shutdownNow();
    }
}
